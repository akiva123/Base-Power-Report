#!/bin/bash
dependencies=(
    "taipy[gui]"
    "pandas"
    "numpy"
    "matplotlib"
    "seaborn"
    "plotly"
)


install_dependencies() {
    echo "Checking and installing required Python packages..."
    for package in "${dependencies[@]}"; do
        if ! python -c "import ${package%%[*]}" &> /dev/null; then
            echo "Installing $package..."
            pip install "$package"
        else
            echo "$package is already installed."
        fi
    done
}


echo "Ensuring pip is installed and up-to-date..."
python -m ensurepip --upgrade
pip install --upgrade pip


install_dependencies

echo "All dependencies are installed and ready to use!"
